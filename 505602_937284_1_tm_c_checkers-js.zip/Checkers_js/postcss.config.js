module.exports = {
    plugins: [
        require('autoprefixer')(
            {
                grid: "autoplace",
                cascade: false,
            }
        )
    ]
};